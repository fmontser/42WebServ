package universitat;

/* 
 * Autor: Francisco Montserrat Rivilla EAC9
 */

public class GestorUniversitatsException extends Exception {
	
	private int	_codi;

	public GestorUniversitatsException() {
		super();
	}

	public GestorUniversitatsException(String message) {
		super(message);
	}

	public GestorUniversitatsException(int codi, String message) {
		super(message);
		_codi = codi;
	}

	@Override
	public String getMessage() {
		return (super.getMessage() + " (Codi " + _codi + ")");
	}
}