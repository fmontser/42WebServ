/**
 * Classe que defineix un campus. Es defineix pel seu nom,
 * la seva ubicació, un array d'aules estàndard,
 * un array d'aules d'informàtica i un array de laboratoris.
 */

package universitat;

import static universitat.UnitatUniversitat.DADES;

import java.util.List;
import java.util.ArrayList;

/**
 * Modificat per Francisco Montserrat Rivilla EAC9
 */

public class Campus implements UnitatUniversitat {

	private String nomCampus;
	private String ubicacio;

	private List<Aula> aules = new ArrayList<>();

	public Campus(String nomCampus, String ubicacio) {
		this.nomCampus = nomCampus;
		this.ubicacio = ubicacio;
	}

	public String getNomCampus() {
		return this.nomCampus;
	}

	public void setNomCampus(String nomCampus) {
		this.nomCampus = nomCampus;
	}

	public String getUbicacio() {
		return this.ubicacio;
	}

	public void setUbicacio(String ubicacio) {
		this.ubicacio = ubicacio;
	}

	public List<Aula> getAules() {
		return aules;
	}

	public void setAules(List<Aula> aules) {
		this.aules = aules;
	}

	public static Campus addCampus() {
		String nom, ubicacio;

		System.out.println("\nNom del campus: ");
		nom = DADES.nextLine();
		System.out.println("\nUbicació del campus: ");
		ubicacio = DADES.nextLine();

		return new Campus(nom, ubicacio);
	}


	@Override
	public void updateUnitatUniversitat() {
		System.out.println("\nNom del campus: " + this.getNomCampus());
		System.out.println("\nEntra el nou nom del campus:");
		this.nomCampus = DADES.nextLine();
		System.out.println("\nUbicació del campus : " + this.getUbicacio());
		System.out.println("\nEntra la nova ubicació del campus:");
		this.ubicacio = DADES.nextLine();
	}

	public double costManteniment() {
		double costTotal = 0;

		for (Aula aula : aules) {
			costTotal += aula.costManteniment();
		}
		return costTotal;
	}
	
	@Override
	public void showUnitatUniversitat() {
		System.out.println("\nLes dades del campus " + this.nomCampus + " són:");
		System.out.println("\nUbicació: " + this.getUbicacio());
		System.out.println("\nCost de manteniment: " + this.costManteniment() + " EUR");
	}
	
	public void addAulaEstandard(AulaEstandard existent) {
		AulaEstandard nouAulaEstandard = null;
		if (existent == null) 
			nouAulaEstandard = AulaEstandard.addAulaEstandard();
		else 
			nouAulaEstandard = existent;
		if (selectAula(1, nouAulaEstandard.getCodi()) == null)
			aules.add(nouAulaEstandard);
		else
			System.out.println("\nAula Estàndard ja existeix");
	}

	public void addAulaInformatica(AulaInformatica existent) {
		AulaInformatica nouAulaInformatica = null;
		if (existent == null) 
			nouAulaInformatica = AulaInformatica.addAulaInformatica();
		else 
			nouAulaInformatica = existent;
		if (selectAula(2, nouAulaInformatica.getCodi()) == null)
			aules.add(nouAulaInformatica);
		else
			System.out.println("\nAula Informàtica ja existeix");
	}

	public void addLaboratori(Laboratori existent) {
		Laboratori nouLaboratori = null;
		if (existent == null) 
			nouLaboratori = Laboratori.addLaboratori();
		else 
			nouLaboratori = existent;
		if (selectAula(3, nouLaboratori.getCodi()) == null)
			aules.add(nouLaboratori);
		else
			System.out.println("\nLaboratori ja existeix");
	}

	public Aula selectAula(int tipusAula, String codi) {
		if (codi == null) {
			switch (tipusAula) {
				case 1:
					System.out.println("Codi de l'aula estàndard: ");
					break;
				case 2:
					System.out.println("Codi de l'aula d'informàtica: ");
					break;
				case 3:
					System.out.println("Codi del laboratori: ");
					break;
			}
			codi = DADES.nextLine();
		}

		for (Aula aula : aules) {
				if (aula instanceof AulaEstandard && tipusAula == 1) {
					if (((AulaEstandard) aula).getCodi().equals(codi)) {
						return aula;
					}
				} else if (aula instanceof AulaInformatica && tipusAula == 2) {
					if (((AulaInformatica) aula).getCodi().equals(codi)) {
						return aula;
					}
				} else if (aula instanceof Laboratori && tipusAula == 3) {
					if (((Laboratori) aula).getCodi().equals(codi)) {
						return aula;
					}
				}
		}
		return null;
	}
}